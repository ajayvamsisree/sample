#!/bin/bash
if [${Deployment_Environment} == Production ] then
${sshkey}= ProdKey
                        
